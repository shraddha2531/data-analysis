-- ============================================================
-- Retail Sales Analytics: SQL queries
-- Table: sales  (loaded from data/processed/retail_sales_clean.csv)
-- Dialect: SQLite (works with minor changes in MySQL/PostgreSQL)
-- ============================================================

-- Q1. Overall KPIs
SELECT COUNT(DISTINCT order_id)                         AS total_orders,
       COUNT(DISTINCT customer_id)                      AS total_customers,
       ROUND(SUM(sales), 2)                             AS total_sales,
       ROUND(SUM(profit), 2)                            AS total_profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2)       AS profit_margin_pct,
       ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2)  AS avg_order_value
FROM sales;

-- Q2. Year-over-year sales growth (window function)
WITH yearly AS (
    SELECT year, ROUND(SUM(sales), 2) AS total_sales
    FROM sales GROUP BY year
)
SELECT year,
       total_sales,
       ROUND((total_sales - LAG(total_sales) OVER (ORDER BY year)) * 100.0
             / LAG(total_sales) OVER (ORDER BY year), 2) AS yoy_growth_pct
FROM yearly;

-- Q3. Sales and profit by category and sub-category
SELECT category, sub_category,
       ROUND(SUM(sales), 2)  AS total_sales,
       ROUND(SUM(profit), 2) AS total_profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2) AS margin_pct
FROM sales
GROUP BY category, sub_category
ORDER BY total_profit DESC;

-- Q4. Region performance with share of total sales
SELECT region,
       ROUND(SUM(sales), 2) AS total_sales,
       ROUND(SUM(sales) * 100.0 / (SELECT SUM(sales) FROM sales), 2) AS pct_of_total
FROM sales
GROUP BY region
ORDER BY total_sales DESC;

-- Q5. Top 10 cities by profit
SELECT city, region, ROUND(SUM(profit), 2) AS total_profit
FROM sales
WHERE city <> 'Unknown'
GROUP BY city, region
ORDER BY total_profit DESC
LIMIT 10;

-- Q6. Impact of discount on profit margin
SELECT discount,
       COUNT(*)                                    AS num_lines,
       ROUND(AVG(profit_margin_pct), 2)            AS avg_margin_pct,
       ROUND(SUM(profit), 2)                       AS total_profit
FROM sales
GROUP BY discount
ORDER BY discount;

-- Q7. Monthly seasonality (average sales per month across years)
SELECT month, month_name,
       ROUND(SUM(sales) / COUNT(DISTINCT year), 2) AS avg_monthly_sales
FROM sales
GROUP BY month, month_name
ORDER BY month;

-- Q8. Top 10 customers by lifetime sales (with rank)
SELECT customer_id, segment,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(SUM(sales), 2)     AS lifetime_sales,
       RANK() OVER (ORDER BY SUM(sales) DESC) AS sales_rank
FROM sales
GROUP BY customer_id, segment
ORDER BY sales_rank
LIMIT 10;

-- Q9. Repeat vs one-time customers
WITH cust AS (
    SELECT customer_id, COUNT(DISTINCT order_id) AS orders FROM sales GROUP BY customer_id
)
SELECT CASE WHEN orders = 1 THEN 'One-time' ELSE 'Repeat' END AS customer_type,
       COUNT(*) AS customers
FROM cust
GROUP BY customer_type;

-- Q10. Shipping performance by ship mode
SELECT ship_mode,
       ROUND(AVG(shipping_days), 2) AS avg_shipping_days,
       COUNT(*)                     AS num_lines
FROM sales
GROUP BY ship_mode
ORDER BY avg_shipping_days;

-- Q11. Loss-making sub-categories / discount combos
SELECT sub_category, discount,
       COUNT(*)              AS loss_lines,
       ROUND(SUM(profit), 2) AS total_loss
FROM sales
WHERE profit < 0
GROUP BY sub_category, discount
ORDER BY total_loss ASC
LIMIT 10;
